MINESWEEPER CHEATER v1.2

HOW TO USE:
Start the program and start minesweeper. Play around to open a sufficiently large area. Now, the new hot keys.
"S" will start the AI loop and will try to SOLVE the game
"H" will run the AI sequence ONCE (i.e. Provide a HINT) 
"F" will TOGGLE the "Best Probability Approach" in the event the AI gets stuck

or alternatively, you can click "START AI" or "HINT" then set the minesweeper window as the foreground window.

The Mouse Click Sleep Interval is by default 0. This sets the time lag, between the following mouse actions.
1: Move Mouse to Location
2: Mouse Down
3: Mouse Up
On slower computers, this value might need to be increased to give Windows more time to react, though I have never seen a computer which is THAT slow yet.

TECHNIQUE DESCRIPTION
Technique 1: if a square has all its mines fulfilled, it will click both mouse buttons on that square.
Technique 2: If a the number of squares around a number square is the same as the number, than it will set all of them as mines

Technique 3-5: Accurate Probability Approach
Technique 3: This will find out which squares definitely will be mines by tracing all the probabilities
Technique 4: This will find out which squares definitely will NOT be mines by tracing the probable positions of the mines around a square
Technique 5: Does the same thing as Technique 4, just at a different position in the loops and also gets a birds eye view of ALL the probabilities tested.
Technique 6: "Best Probability Approach". INACCURATE. Will set a square to be a mine if the probabilty that it IS a mine is high enough

CHANGES since v1.0:
1: Techniques 4 and 5 added
2: Technique 6 increase in accuracy
3: Program Name changed
4: Hotkey capability
5: Hinting
6: Error Checking
CREDITS:
Whoever wrote the VBKEYBOARDHOOK.DLL. I am sorry to forget who you are, but Thanks for providing me with such a wonderful dll.

KNOWN PROBLEMS:
Still will not work on WINDOWS NT/WINDOWS 2000 due to minesweeper incompatibilities.
Thus I recommend whoever finds that this program does not work, try to procure from friends a win 9x version of minesweeper.
